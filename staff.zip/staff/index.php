<?php
$active = "index";
$title = "staff home page";
include('header.php')

?>

 <!-- home page header-->
<div class="text-center" style="margin-top: 20vh;">
    <h3> Staff Home Page </h3>
</div>


</div>
</body>
</html>